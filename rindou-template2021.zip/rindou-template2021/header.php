<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?> id="body">
    <header id="header-fixed" class="header-container">
        <div class="header container">
            <div class="header-logo">
                <p class="header-logo__subtitle logo-subtitle"><?php bloginfo( 'description' ); ?></p>
                    <?php
                    the_custom_logo();
                    if (!has_custom_logo()) { ?>
                        <a href="<?php bloginfo( 'url' ); ?>" class="header-logo__link"><?php bloginfo('name');?></a>
                    <?php }
                    ?>
            </div>
          </div>
            <nav id="site-navigation" class="main-navigation container" role="navigation">
                <ul class="main-navigation__menu">
                    <?php
                    if ( has_nav_menu( 'primary' ) ) {

                        wp_nav_menu(
                            array(
                                'container'  => '',
                                'items_wrap' => '%3$s',
                                'theme_location' => 'primary',
                            )
                        );

                    } elseif ( ! has_nav_menu( 'expanded' ) ) {

                        wp_list_pages(
                            array(
                                'match_menu_classes' => true,
                                'show_sub_menu_icons' => true,
                                'title_li' => false,
                            )
                        );

                    }
                    ?>
                </ul>
            </nav>
            <div class="hamburger" id="js-hamburger">
                <span class="hamburger__line hamburger__line--1"></span>
                <span class="hamburger__line hamburger__line--2"></span>
                <span class="hamburger__line hamburger__line--3"></span>
            </div>
            <div class="hamburger-bg" id="js-hamburger-bg"></div>
    </header>
    <?php
     $page = get_post( get_the_ID() );
     $slug = $page->post_name;
     $title = $page->post_title;
     $cat = get_queried_object();
    $cat_name = $cat -> name;
    $cat_slug = $cat -> slug;

     $page_title    = '';
     $page_subtitle = '';


    if ( is_search() ) {
        global $wp_query;

        $page_title = sprintf(
            '「' . get_search_query() . '」の検索結果'
        );

        if ( $wp_query->found_posts ) {
            $page_subtitle = sprintf(
                 '%s件の記事が見つかりました',
                number_format_i18n( $wp_query->found_posts )
            );
        } else {
            $page_subtitle = '記事が見つかりませんでした。';
        }
    } elseif ( is_category() ) {
        $page_title    = $cat_name;
        $page_subtitle = $cat_slug;
    } elseif ( is_archive() ) {
        $page_title    = get_the_archive_title();
        $page_subtitle = get_the_archive_description();
    } elseif ( is_page() ) {
        $page_title    = $title;
        $page_subtitle = $slug;
    } elseif ( is_404() ) {
        $page_title    = 'ページが見つかりません';
        $page_subtitle = 'Not Found';
    } elseif ( is_home() ) {
      $page_title    = get_bloginfo('name');
      $page_subtitle = 'Blog List';
    }
    ?>

<?php if(is_page()):?>
  <?php if(!is_page_template( 'templates/template-cover.php' )): ?>
  <div class="article-header">
      <div class="article-header__item container">
          <h1 class="article-header__title"><?php the_title();?></h1>
      </div>
  </div>
  <?php endif;?>
<?php endif;?>

<?php if(!is_page()):?>
  <?php if( !is_front_page() and !is_home() ): ?>
  <div class="breadcrumb-list">
    <div class="container">
    <?php if( is_front_page() && is_home() ): ?>
    <?php else:?>
        <?php
            if(function_exists('bcn_display'))
            {
                bcn_display();
            }
        ?>
    <?php endif;?>
    </div>
  </div>
  <?php endif;?>
  <div class="wrapper">
    <?php if(is_single()):?>
    <main id="main" class="main" role="main">
      <div class="article-header">
          <div class="article-header__item">
              <h1 class="article-header__title"><?php the_title();?></h1>
              <?php get_template_part( 'template-parts/content-meta' );?>
          </div>
      </div>
      <?php else:?>
      <main id="main" class="main" role="main">
      <div class="article-header">
        <div class="article-header__item">
        <h1 class="article-header__title"><?php echo $page_title; ?></h1>
        </div>
      </div>
    <?php endif;?>
<?php endif;?>
