    <?php if(!is_page()):?>
    <aside class="aside">
        <div class="aside-widget">
            <?php dynamic_sidebar( 'sidebar-1' ); ?>
        </div>
    </aside>
  </div><!--/.wrapper-->
    <?php endif;?>
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-contact">
                <div class="footer-contact-container">
                    <div class="footer-contact-container__address">
                        <p class="footer__subtitle logo-subtitle"><?php bloginfo( 'description' ); ?></p>
                        <?php
                        the_custom_logo();
                        ?>
                        <?php $author = 1;
                        ?>
                        <h4 class="footer-contact-container__address--title"><?php bloginfo('name');?></h4>
                        <?php if(get_the_author_meta('shop_address',$author) != ""): ?><p class="footer-contact-container__address--text"><?php the_author_meta('shop_address',$author); ?></p><?php endif; ?>
                        <?php if(get_the_author_meta('free_input',$author) != ""): ?><div class="footer-contact-container__address--text"><?php echo wpautop(get_the_author_meta('free_input',$author)); ?></div><?php endif; ?>
                    </div>
                    <?php if((get_the_author_meta('user_url',$author) != "") || (get_the_author_meta('facebook',$author) != "") || (get_the_author_meta('twitter',$author) != "") || (get_the_author_meta('instagram',$author) != "") || (get_the_author_meta('youtube',$author) != "") || (get_the_author_meta('contact_url',$author) != "") || (get_the_author_meta('shop_tell',$author) != "") || (get_the_author_meta('business_hours',$author) != "") || (get_the_author_meta('facebook',$author) != "") || (get_the_author_meta('twitter',$author) != "") || (get_the_author_meta('instagram',$author) != "") || (get_the_author_meta('youtube',$author) != "")): ?>
                    <div class="footer-contact-container__online">
                    <?php endif; ?>
                        <?php if(get_the_author_meta('contact_url',$author) != ""): ?>
                        <div class="footer-contact-container__online--mail">
                            <a href="<?php the_author_meta('contact_url',$author); ?>" class="button" data-wpel-link="internal">お問い合わせ</a>
                        </div>
                        <?php endif; ?>
                        <?php if((get_the_author_meta('shop_tell',$author) != "") || (get_the_author_meta('business_hours',$author) != "")): ?><div class="footer-contact-container__online--tel"><?php endif; ?>
                            <?php if(get_the_author_meta('shop_tell',$author) != ""): ?><?php the_author_meta('shop_tell',$author); ?><?php endif; ?><?php if(get_the_author_meta('business_hours',$author) != ""): ?><span class="footer-contact-container__online--tel-text"><?php the_author_meta('business_hours',$author); ?></span><?php endif; ?><?php if((get_the_author_meta('shop_tell',$author) != "") || (get_the_author_meta('business_hours',$author) != "")): ?></div><?php endif; ?>
                        <?php if((get_the_author_meta('user_url',$author) != "") || (get_the_author_meta('facebook',$author) != "") || (get_the_author_meta('twitter',$author) != "") || (get_the_author_meta('instagram',$author) != "") || (get_the_author_meta('youtube',$author) != "")): ?>
                        <div class="sns">
                        <?php endif; ?>
                            <?php if(get_the_author_meta('user_url',$author) != ""): ?>
                            <a href="<?php the_author_meta('user_url',$author); ?>" class="sns-item" target="_blank" rel="noopener"><i class="fas fa-globe fa-fw"></i></a>
                            <?php endif; ?>
                            <?php if(get_the_author_meta('facebook',$author) != ""): ?>
                            <a href="<?php the_author_meta('facebook',$author); ?>" class="sns-item" target="_blank" rel="noopener"><i class="fab fa-facebook-f fa-fw"></i></a>
                            <?php endif; ?>
                            <?php if(get_the_author_meta('twitter',$author) != ""): ?>
                            <a href="<?php the_author_meta('twitter',$author); ?>" class="sns-item" target="_blank" rel="noopener"><i class="fab fa-twitter fa-fw"></i></a>
                            <?php endif; ?>
                            <?php if(get_the_author_meta('instagram',$author) != ""): ?>
                            <a href="<?php the_author_meta('instagram',$author); ?>" class="sns-item" target="_blank" rel="noopener"><i class="fab fa-instagram fa-fw"></i></a>
                            <?php endif; ?>
                            <?php if(get_the_author_meta('youtube',$author) != ""): ?>
                            <a href="<?php the_author_meta('youtube',$author); ?>" class="sns-item" target="_blank" rel="noopener"><i class="fab fa-youtube fa-fw"></i></a>
                            <?php endif; ?>
                        <?php if((get_the_author_meta('user_url',$author) != "") || (get_the_author_meta('facebook',$author) != "") || (get_the_author_meta('twitter',$author) != "") || (get_the_author_meta('instagram',$author) != "") || (get_the_author_meta('youtube',$author) != "")): ?>
                        </div>
                        <?php endif; ?>
                    <?php if((get_the_author_meta('user_url',$author) != "") || (get_the_author_meta('facebook',$author) != "") || (get_the_author_meta('twitter',$author) != "") || (get_the_author_meta('instagram',$author) != "") || (get_the_author_meta('youtube',$author) != "") || (get_the_author_meta('contact_url',$author) != "") || (get_the_author_meta('shop_tell',$author) != "") || (get_the_author_meta('business_hours',$author) != "") || (get_the_author_meta('facebook',$author) != "") || (get_the_author_meta('twitter',$author) != "") || (get_the_author_meta('instagram',$author) != "") || (get_the_author_meta('youtube',$author) != "")): ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="footer-menu">
                <nav>
                    <ul>
                    <?php
                    if ( has_nav_menu( 'footer' ) ) {

                        wp_nav_menu(
                            array(
                                'container'  => '',
                                'items_wrap' => '%3$s',
                                'theme_location' => 'footer',
                            )
                        );

                    } elseif ( ! has_nav_menu( 'expanded' ) ) {

                        wp_list_pages(
                            array(
                                'match_menu_classes' => true,
                                'show_sub_menu_icons' => true,
                                'title_li' => false,
                            )
                        );

                    }
                    ?>
                    </ul>
                </nav>
            </div>
        </div>
        <div class="footer-copyright">© <?php echo date('Y'); ?> <?php bloginfo( 'name' ); ?></div>
    </footer>
    <?php wp_footer(); ?>
</body>

</html>
