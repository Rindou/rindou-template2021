//ハンバーガー
function toggleNav() {
  var body = document.body;
  var hamburger = document.getElementById('js-hamburger');
  var blackBg = document.getElementById('js-hamburger-bg');
  var hamburgerClose = document.getElementById('js-hamburger-close');

  hamburger.addEventListener('click', function() {
    body.classList.toggle('nav-open');
  });
  blackBg.addEventListener('click', function() {
    body.classList.remove('nav-open');
  });
  hamburgerClose.addEventListener('click', function() {
    body.classList.remove('nav-open');
  });
}
toggleNav();
