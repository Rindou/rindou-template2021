<div class="article-4column__list">
	<a href="<?php the_permalink() ?>" rel="bookmark" class="article-4column__list--link">
	<span href="<?php the_permalink() ?>" rel="bookmark" class="article-4column__list--link article-4column__list--link-image-box">
	<?php if ( has_post_thumbnail() ) { ?>
	<?php the_post_thumbnail( 'large', array( 'class' => 'article-4column__list--link-image' ) ); ?>
	<?php } else {?>
	<img src="<?php echo get_template_directory_uri(); ?>/assets/images/noimage.png" class="article-4column__list--link-image">
	<?php } ?>
	</span>
	<span class="article-4column__list--date"><?php the_time('Y年n月j日');?></span><span class="article-4column__list--title"><?php the_title(); ?></span></a>
</div>