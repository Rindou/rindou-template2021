<?php get_header();?>
  <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
        <div class="article-list">
            <div class="article-list__image">
            <?php if ( has_post_thumbnail() ) : ?>
                    <a href="<?php the_permalink();?>" class="article-list__link"><?php the_post_thumbnail( 'large', array( 'class' => 'article-list__link--image' )  ); ?></a>
                <?php else:?>
                    <a href="<?php the_permalink();?>" class="article-list__link"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/noimage.png" class="article-list__link--image"></a>
            <?php endif;?>
            </div>
            <div class="article-list__content">
                <h2 class="article-list__title"><a href="<?php the_permalink();?>" class="article-list__title-link"><?php the_title();?></a></h2>
                <div class="article-list__text">
                  <a href="<?php the_permalink();?>" class="article-list__text-link"><?php the_excerpt();?></a>
                </div>
                <?php get_template_part( 'template-parts/content-meta' );?>
            </div>
        </div>
    <?php endwhile; else : ?>
      <p>記事が見つかりませんでした。</p>
    <?php endif;?>
    <?php if ( is_plugin_active( 'wp-pagenavi/wp-pagenavi.php' ) ) : ?>
        <nav class="page-navigation" role="navigation" aria-label="投稿">
            <?php wp_pagenavi(); ?>
        </nav>
    <?php endif;?>
    </main>
<?php get_footer();?>
