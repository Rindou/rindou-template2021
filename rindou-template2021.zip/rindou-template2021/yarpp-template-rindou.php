<?php
/*
YARPP Template: リンドウ
*/
?>
<?php if (have_posts()):?>
        <aside class="content-aside">
            <h4 class="content-aside__title">＼こちらもおすすめ／</h4>
            <div class="article-4column">
	<?php while (have_posts()) : the_post(); ?>
	<?php get_template_part( 'template-parts/content-4column__list' );?>
	<?php endwhile; ?>
            </div>
        </aside>
<?php else: ?>
<?php endif; ?>
