<?php get_header();?>
    <div class="article-header">
        <div class="article-header__item">
            <h1 class="article-header__title">404:ページが見つかりません</h1>
        </div>

    </div>
    <div class="breadcrumb-list">
    <?php 
    if ( !is_home() ) {
        if(function_exists('bcn_display'))
        {
            bcn_display();
        }
    }
    ?>
    </div>
    <main id="main" class="site-main one-column" role="main">

    <p>お探しのページは削除されたか、名前が変更されたか、最初から存在しなかった可能性があります。</p>

    </main>
<?php get_footer();?>